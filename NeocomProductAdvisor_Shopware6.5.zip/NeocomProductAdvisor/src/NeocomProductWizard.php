<?php

declare(strict_types=1);

namespace Neocom\ProductWizard;

use Shopware\Core\Framework\Plugin;

class NeocomProductWizard extends Plugin
{
}