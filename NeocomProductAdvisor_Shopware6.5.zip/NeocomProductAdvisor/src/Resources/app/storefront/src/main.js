import NeocomPurchaseTrackingPlugin from "./neocom/purchase-tracking/neocom-purchase-tracking.plugin";

const PluginManager = window.PluginManager;

if (PluginManager.getPlugin('NeocomPurchaseTracking') === undefined) {
    PluginManager.register('NeocomPurchaseTracking', NeocomPurchaseTrackingPlugin, '[data-neocom-purchase-tracking]');
}