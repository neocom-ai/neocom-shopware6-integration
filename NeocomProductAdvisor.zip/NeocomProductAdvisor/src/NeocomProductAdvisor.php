<?php

declare(strict_types=1);

namespace Neocom\ProductAdvisor;

use Shopware\Core\Framework\Plugin;

class NeocomProductAdvisor extends Plugin
{
}