import Plugin from 'src/plugin-system/plugin.class';

export default class NeocomPurchaseTrackingPlugin extends Plugin {
    static options = {
        order: null
    };

    init() {
        //Check if Neocom is loaded, otherwise call the trackPurchase method asynchronously
        if (window.Neocom === undefined) {
            this._subscribeEvents();
        } else {
            this.trackPurchase(this.options.order);
        }
    }

    _subscribeEvents() {
        window.addEventListener("neocomloaded", this._onNeocomLoaded.bind(this));
    }

    trackPurchase(order) {
        //Track purchase only if Neocom is loaded and we have an order
        if (window.Neocom === undefined || this.options.order == null) {
            return;
        }

        let purchase = {
            value: order.amountTotal,
            currency: order.currency.isoCode,
            order_id: order.id,
            contents: []
        }

        order.lineItems.forEach((lineItem) => {
            //We only want to track products
            if (lineItem.type !== 'product') {
                return;
            }

            purchase.contents.push({
                id: lineItem.payload.productNumber,
                quantity: lineItem.quantity,
                price: lineItem.unitPrice,
            });
        });

        this.$emitter.publish('beforeNeocomPurchaseTracker', purchase);

        window.Neocom.trackPurchase(purchase);

        this.$emitter.publish('afterNeocomPurchaseTracker', purchase);
    }

    _onNeocomLoaded() {
        this.trackPurchase(this.options.order);
    };
}