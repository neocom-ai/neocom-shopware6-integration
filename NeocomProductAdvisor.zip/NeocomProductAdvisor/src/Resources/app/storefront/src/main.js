import NeocomPurchaseTrackingPlugin from "./neocom/purchase-tracking/neocom-purchase-tracking.plugin";

const PluginManager = window.PluginManager;
PluginManager.register('NeocomPurchaseTracking', NeocomPurchaseTrackingPlugin, '[data-neocom-purchase-tracking]');