<?php

declare(strict_types=1);

namespace Neocom\ProductAdvisor\Subscriber;

use Shopware\Core\Checkout\Cart\Event\CheckoutOrderPlacedEvent;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\System\SystemConfig\SystemConfigService;
use Shopware\Storefront\Page\Checkout\Finish\CheckoutFinishPageOrderCriteriaEvent;
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class OrderPlacedSubscriber implements EventSubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return [
            CheckoutOrderPlacedEvent::class => 'onOrderPlaced',
            CheckoutFinishPageOrderCriteriaEvent::class => 'onOrderFinishPageCriteria'
        ];
    }

    public function __construct(
        private readonly EntityRepository    $orderRepository,
        private readonly SystemConfigService $systemConfigService
    )
    {

    }

    /**
     * In addition to the regular order information we need the currency ISO code for the purchase tracking as well.
     *
     * @param CheckoutFinishPageOrderCriteriaEvent $event
     * @return void
     */
    public function onOrderFinishPageCriteria(CheckoutFinishPageOrderCriteriaEvent $event): void
    {
        $event->getCriteria()->addAssociation('currency');
    }

    /**
     * Mark the order as untracked for the purchase tracking.
     *
     * @param CheckoutOrderPlacedEvent $event
     * @return void
     */
    public function onOrderPlaced(CheckoutOrderPlacedEvent $event): void
    {
        //Enable purchase tracking?
        if (!$this->systemConfigService->get('NeocomProductAdvisor.config.enablePurchaseTracking')) {
            return;
        }

        $customFields = array_merge($event->getOrder()->getCustomFields() ?? [], ['neocomPurchaseTracked' => false]);
        $payload = [
            'id' => $event->getOrderId(),
            'customFields' => $customFields
        ];

        $this->orderRepository->upsert([$payload], $event->getContext());
    }
}