<?php

declare(strict_types=1);

namespace Neocom\ProductAdvisor\Storefront\Page\Checkout\Finish;

use Shopware\Core\Checkout\Order\SalesChannel\AbstractOrderRoute;
use Shopware\Core\Framework\Adapter\Translation\AbstractTranslator;
use Shopware\Core\Framework\DataAbstractionLayer\EntityRepository;
use Shopware\Core\System\SalesChannel\SalesChannelContext;
use Shopware\Storefront\Page\Checkout\Finish\CheckoutFinishPage;
use Shopware\Storefront\Page\Checkout\Finish\CheckoutFinishPageLoader as CoreCheckoutFinishPageLoader;
use Shopware\Storefront\Page\GenericPageLoaderInterface;
use Symfony\Component\EventDispatcher\EventDispatcherInterface;
use Symfony\Component\HttpFoundation\Request;

class CheckoutFinishPageLoader extends CoreCheckoutFinishPageLoader
{
    public function __construct(
        private readonly EventDispatcherInterface   $eventDispatcher,
        private readonly GenericPageLoaderInterface $genericLoader,
        private readonly AbstractOrderRoute         $orderRoute,
        private readonly AbstractTranslator         $translator,
        private readonly EntityRepository           $orderRepository
    ) {
        parent::__construct($this->eventDispatcher, $this->genericLoader, $this->orderRoute, $this->translator);
    }

    public function load(Request $request, SalesChannelContext $salesChannelContext): CheckoutFinishPage
    {
        $page = parent::load($request, $salesChannelContext);
        $order = $page->getOrder();

        //If the custom field does not exist at all, we can consider the purchase tracking inactive.
        if (!array_key_exists('neocomPurchaseTracked', $order->getCustomFields())) {
            return $page;
        }

        //If the order has already been tracked, we can skip the tracking
        if ($page->getOrder()->getCustomFieldsValue('neocomPurchaseTracked')) {
            return $page;
        }

        //Mark the order to be tracked by Neocom
        $customFields = array_merge($page->getOrder()->getCustomFields() ?? [], ['neocomPurchaseTracked' => true]);
        $payload = [
            'id' => $page->getOrder()->getId(),
            'customFields' => $customFields
        ];

        try {
            $this->orderRepository->upsert([$payload], $salesChannelContext->getContext());

            //Tell the finish page to track the order by adding the extension to the page
            $page->addArrayExtension('neocom', ['trackPurchase' => true]);
        } catch (\Exception $e) {
            return $page;
        }

        return $page;
    }
}