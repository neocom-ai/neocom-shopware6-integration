<?php

declare(strict_types=1);

namespace Neocom\ProductAdvisor\Framework\Cookie;

use Shopware\Core\System\SystemConfig\SystemConfigService;
use Shopware\Storefront\Framework\Cookie\CookieProviderInterface;

class NeocomCookieProvider implements CookieProviderInterface
{
    private const NEOCOM_COOKIE = [
        'snippet_name' => 'neocom.cookie.label',
        'snippet_description' => 'neocom.cookie.description',
        'cookie' => 'neocom-cookie',
        'expiration' => '30',
        'value' => '1',
    ];

    public function __construct(private readonly CookieProviderInterface $originalService, private readonly SystemConfigService $systemConfigService)
    {
    }

    public function getCookieGroups(): array
    {
        $cookies = $this->originalService->getCookieGroups();

        if ($this->systemConfigService->get('NeocomProductAdvisor.config.enableShopwareCookies')) {
            return $this->addCookieToTechnicalRequiredGroup($cookies);
        }

        return $cookies;
    }

    private function addCookieToTechnicalRequiredGroup(array $cookies): array
    {
        foreach ($cookies as &$cookie) {
            if (!\is_array($cookie)) {
                continue;
            }

            if (!$this->isRequiredCookieGroup($cookie)) {
                continue;
            }

            if (!\array_key_exists('entries', $cookie)) {
                continue;
            }

            $cookie['entries'][] = self::NEOCOM_COOKIE;
        }

        return $cookies;
    }

    private function addNeocomCookie(array $cookies)
    {
        $cookies[] = self::NEOCOM_COOKIE;

        return $cookies;
    }

    private function isRequiredCookieGroup(array $cookie): bool
    {
        return (\array_key_exists('isRequired', $cookie) && $cookie['isRequired'] === true)
            && (\array_key_exists('snippet_name', $cookie) && $cookie['snippet_name'] === 'cookie.groupRequired');
    }
}