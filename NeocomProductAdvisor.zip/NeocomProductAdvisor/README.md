# Neocom | Guided Selling for Shopware 6

## Description

The Neocom | Guided Selling is a plugin for Shopware 6 that allows you to create a guided selling experience for your customers. 
The plugin is designed to help customers find the right products by asking them a series of questions. 
The questions can be customized to suit your needs, and the plugin can be used to create product finders, product configurators, and more.

In addition to the guided selling functionality, the plugin also provides order tracking as well.

## Installation & Setup

To install and setup the plugin, follow these steps:

1. Install & activate the plugin using the shopware plugin manager (upload the NeocomProductAdvisor.zip as extension)
2. Go to the plugin settings (in the plugin list use the `...` button and click `configure`)
3. Enter your Neocom Client-ID and activate the features you want
4. Make sure that you clear all caches